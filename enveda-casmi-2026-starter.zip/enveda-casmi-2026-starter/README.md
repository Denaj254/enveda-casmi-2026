# Enveda CASMI 2026 starter

## Setup
1. Create a **private** GitHub repository named `enveda-casmi-2026`.
2. Upload this scaffold (or unzip it and push with Git).
3. In Kaggle, open the competition → Code → New Notebook, then attach the competition dataset.
4. Run `notebooks/01_baseline.py` in notebook cells. It discovers the mounted dataset and profiles the files.

Do not commit Parquet data, Kaggle API tokens, credentials, or large model artifacts.

## Strategy
Start with data/schema reconnaissance, then establish a leakage-safe validation split grouped by molecule, then build precursor-filtered spectral retrieval and molecule-level aggregation. The competition scores the first correct structure in a ranked list of up to 25 candidates, per molecule (not per spectrum).

## Important
The included baseline is a correctness-first prototype, not a competitive result. It searches a deterministic sample of training spectra and is intended to validate the end-to-end path. The next iteration should use a vectorized sparse spectrum index and molecule-grouped validation.
