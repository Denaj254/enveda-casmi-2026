# Enveda CASMI 2026 — Kaggle Notebook starter
from pathlib import Path
import glob
import numpy as np
import pandas as pd

# Cell 1: locate competition files
test_paths = glob.glob("/kaggle/input/**/test.parquet", recursive=True)
print("Found test files:", test_paths)
if not test_paths:
    raise FileNotFoundError("Attach the competition dataset to this Kaggle Notebook.")
DATA = Path(test_paths[0]).parent
TRAIN_PATH, TEST_PATH = DATA/"train.parquet", DATA/"test.parquet"
SAMPLE_PATH = DATA/"sample_submission.csv"

# Cell 2: inspect test and submission schema
test = pd.read_parquet(TEST_PATH)
sample = pd.read_csv(SAMPLE_PATH)
print("Test shape:", test.shape)
print("Test columns:", test.columns.tolist())
print("Spectra per molecule summary:")
print(test.groupby("molecule_id").size().describe())
print("Sample submission:", sample.shape, sample.columns.tolist())
print("Adduct counts:")
print(test["adduct"].value_counts(dropna=False))
print("Ionization mode counts:")
print(test["ionization_mode"].value_counts(dropna=False))

# Cell 3: read a small, deterministic slice of training data to smoke-test the pipeline.
# Once this works, increase the slice or build a vectorized index over the full dataset.
TRAIN_ROWS_FOR_SMOKE_TEST = 50000
# Read only a few Parquet row groups instead of materializing the entire ~3 GB training file.
import pyarrow.parquet as pq
pf = pq.ParquetFile(TRAIN_PATH)
print("Train row groups:", pf.num_row_groups, "| total rows:", pf.metadata.num_rows)
needed = ["precursor_mz", "adduct", "normalized_smiles", "inchikey14"]
if "ingest_lib" in pf.schema.names:
    needed.append("ingest_lib")
chunks, rows_read = [], 0
for rg in range(pf.num_row_groups):
    chunk = pf.read_row_group(rg, columns=needed).to_pandas()
    chunks.append(chunk)
    rows_read += len(chunk)
    if rows_read >= TRAIN_ROWS_FOR_SMOKE_TEST:
        break
train_small = pd.concat(chunks, ignore_index=True).head(TRAIN_ROWS_FOR_SMOKE_TEST)
print("Loaded training smoke-test rows:", train_small.shape)
print("Top source libraries:")
if "ingest_lib" in train_small:
    print(train_small["ingest_lib"].value_counts(dropna=False).head(10))
print("Train sample:")
print(train_small[["precursor_mz", "adduct", "normalized_smiles", "inchikey14"]].head())

# Cell 4: small precursor-mass retrieval baseline.
# This ranks training structures with nearby precursor m/z. It is deliberately a simple
# benchmark to validate output plumbing, not a final spectral similarity model.
train_small = train_small.dropna(subset=["precursor_mz", "normalized_smiles"])
mass = train_small["precursor_mz"].to_numpy(dtype=float)
smiles = train_small["normalized_smiles"].astype(str).to_numpy()
keys = train_small["inchikey14"].astype(str).to_numpy() if "inchikey14" in train_small else smiles

# Candidate ranking uses nearest precursor m/z, with duplicate structures deduplicated.
# Spectrum-aware scoring is the next upgrade.
submission_rows = []
for n, molecule_id in enumerate(sample["molecule_id"]):
    group = test[test["molecule_id"] == molecule_id]
    scores = {}
    for row in group.itertuples(index=False):
        distance = np.abs(mass - float(row.precursor_mz))
        nearby = np.flatnonzero(distance <= 0.05)
        if len(nearby) == 0:
            nearby = np.argsort(distance)[:100]
        # Keep each structure's best mass match across all spectra for this molecule.
        for j in nearby:
            smi = smiles[j]
            score = -float(distance[j])
            if smi not in scores or score > scores[smi]:
                scores[smi] = score
    ranked = [s for s, _ in sorted(scores.items(), key=lambda kv: kv[1], reverse=True)[:25]]
    if not ranked:
        ranked = ["CCO"]  # valid-format fallback only; should be rare and is not a chemistry prediction
    submission_rows.append({"molecule_id": molecule_id, "smiles": ";".join(ranked)})
    if (n + 1) % 50 == 0:
        print(f"Processed {n+1}/{len(sample)} molecules")

submission = pd.DataFrame(submission_rows)
assert submission.columns.tolist() == ["molecule_id", "smiles"]
assert submission["molecule_id"].is_unique
assert submission["smiles"].notna().all() and (submission["smiles"].str.len() > 0).all()
assert (submission["smiles"].str.split(";").str.len() <= 25).all()
out = "/kaggle/working/submission_baseline.csv"
submission.to_csv(out, index=False)
print("Wrote", out, "shape=", submission.shape)
print(submission.head().to_string(index=False))
