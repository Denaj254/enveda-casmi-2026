def mrr_at_25(predictions, truth_by_molecule, k=25):
    """predictions: molecule_id -> ranked candidate IDs; truth_by_molecule: molecule_id -> true ID."""
    import numpy as np
    values = []
    for molecule_id, truth in truth_by_molecule.items():
        score = 0.0
        for rank, candidate in enumerate(predictions.get(molecule_id, [])[:k], 1):
            if candidate == truth:
                score = 1.0 / rank
                break
        values.append(score)
    return float(np.mean(values)) if values else 0.0
